#!/bin/bash

ansi_code(){	
	local CODES=""
	local ARGUMENTS=" ${*: 1:$#-1} " # all arguments but last
	local TEXT="${*: -1}" # last argument
	
	if [[ "$ARGUMENTS" = *" BOLD "* ]]; then
		CODES="1;";
	fi	
	if [[ "$ARGUMENTS" = *" FAINT "* ]]; then
		CODES="${CODES}2;";
	fi
	if [[ "$ARGUMENTS" = *" ITALIC "* ]]; then
		CODES="${CODES}3;";
	fi
	if [[ "$ARGUMENTS" = *" UNDERLINE "* ]]; then
		CODES="${CODES}4;";
	fi
	if [[ "$ARGUMENTS" = *" BLINK "* ]]; then
		CODES="${CODES}5;";
	fi
	if [[ "$ARGUMENTS" = *" FBLINK "* ]]; then
		CODES="${CODES}6;";
	fi
	if [[ "$ARGUMENTS" = *" REVERSE "* ]]; then
		CODES="${CODES}7;";
	fi
	if [[ "$ARGUMENTS" = *" HIDE "* ]]; then
		CODES="${CODES}8;";
	fi
	if [[ "$ARGUMENTS" = *" STRIKE "* ]]; then
		CODES="${CODES}9;";
	fi
	if [[ "$ARGUMENTS" = *" DUNDERLINE "* ]]; then
		CODES="${CODES}21;";
	fi
	if [[ "$ARGUMENTS" = *" NORMAL "* ]]; then
		CODES="${CODES}22;";
	fi
	
	if [[ "$ARGUMENTS" = *" BLACK "* ]]; then
		CODES="${CODES}30;";
	fi
	if [[ "$ARGUMENTS" = *" RED "* ]]; then
		CODES="${CODES}31;";
	fi
	if [[ "$ARGUMENTS" = *" GREEN "* ]]; then
		CODES="${CODES}32;";
	fi
	if [[ "$ARGUMENTS" = *" YELLOW "* ]]; then
		CODES="${CODES}33;";
	fi
	if [[ "$ARGUMENTS" = *" BLUE "* ]]; then
		CODES="${CODES}34;";
	fi
	if [[ "$ARGUMENTS" = *" MAGENTA "* ]]; then
		CODES="${CODES}35;";
	fi
	if [[ "$ARGUMENTS" = *" CYAN "* ]]; then
		CODES="${CODES}36;";
	fi
	if [[ "$ARGUMENTS" = *" WHITE "* ]]; then
		CODES="${CODES}37;";
	fi
	if echo "$ARGUMENTS" | grep -qP ' COLOR_([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]) '; then
		CODES="${CODES}38;5;$(echo "$ARGUMENTS" |  sed -r 's/.* COLOR_([0-9]+) .*/\1/');";
	fi		
	if echo "$ARGUMENTS" | grep -qP ' COLOR_(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])_){2}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]) '; then
		CODES="${CODES}38;2;$(echo "$ARGUMENTS" |  sed -r 's/.* COLOR_([0-9]+_[0-9]+_[0-9]+) .*/\1/; s/_/;/g');";
	fi
	if [[ "$ARGUMENTS" = *" COLOR_DEFAULT "* ]]; then
		CODES="${CODES}39;";
	fi	
	
	if [[ "$ARGUMENTS" = *" BLACK_BG "* ]]; then
		CODES="${CODES}40;";
	fi
	if [[ "$ARGUMENTS" = *" RED_BG "* ]]; then
		CODES="${CODES}41;";
	fi
	if [[ "$ARGUMENTS" = *" GREEN_BG "* ]]; then
		CODES="${CODES}42;";
	fi
	if [[ "$ARGUMENTS" = *" YELLOW_BG "* ]]; then
		CODES="${CODES}43;";
	fi
	if [[ "$ARGUMENTS" = *" BLUE_BG "* ]]; then
		CODES="${CODES}44;";
	fi
	if [[ "$ARGUMENTS" = *" MAGENTA_BG "* ]]; then
		CODES="${CODES}45;";
	fi
	if [[ "$ARGUMENTS" = *" CYAN_BG "* ]]; then
		CODES="${CODES}46;";
	fi
	if [[ "$ARGUMENTS" = *" WHITE_BG "* ]]; then
		CODES="${CODES}47;";
	fi	
	if echo "$ARGUMENTS" | grep -qP ' COLOR_BG_([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]) '; then
		CODES="${CODES}48;5;$(echo "$ARGUMENTS" |  sed -r 's/.* COLOR_BG_([0-9]+) .*/\1/');";
	fi		
	if echo "$ARGUMENTS" | grep -qP ' COLOR_BG_(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])_){2}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]) '; then
		CODES="${CODES}48;2;$(echo "$ARGUMENTS" |  sed -r 's/.* COLOR_BG_([0-9]+_[0-9]+_[0-9]+) .*/\1/; s/_/;/g');";
	fi
	if [[ "$ARGUMENTS" = *" COLOR_BG_DEFAULT "* ]]; then
		CODES="${CODES}49;";
	fi	
	
	if [[ "$ARGUMENTS" = *" OVERLINE "* ]]; then
		CODES="${CODES}53;";
	fi
	
	if [[ "$ARGUMENTS" = *" BRIGHT_BLACK "* ]]; then
		CODES="${CODES}90;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_RED "* ]]; then
		CODES="${CODES}91;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_GREEN "* ]]; then
		CODES="${CODES}92;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_YELLOW "* ]]; then
		CODES="${CODES}93;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_BLUE "* ]]; then
		CODES="${CODES}94;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_MAGENTA "* ]]; then
		CODES="${CODES}95;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_CYAN "* ]]; then
		CODES="${CODES}96;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_WHITE "* ]]; then
		CODES="${CODES}97;";
	fi
	
	if [[ "$ARGUMENTS" = *" BRIGHT_BLACK_BG "* ]]; then
		CODES="${CODES}100;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_RED_BG "* ]]; then
		CODES="${CODES}101;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_GREEN_BG "* ]]; then
		CODES="${CODES}102;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_YELLOW_BG "* ]]; then
		CODES="${CODES}103;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_BLUE_BG "* ]]; then
		CODES="${CODES}104;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_MAGENTA_BG "* ]]; then
		CODES="${CODES}105;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_CYAN_BG "* ]]; then
		CODES="${CODES}106;";
	fi
	if [[ "$ARGUMENTS" = *" BRIGHT_WHITE_BG "* ]]; then
		CODES="${CODES}107;";
	fi	
	
	if echo "$ARGUMENTS" | grep -qP ' CODE_[0-9_]+ '; then
		CODES="${CODES}$(echo "$ARGUMENTS" |  sed -r 's/.* CODE_([0-9_]+) .*/\1/; s/_/;/g');";
	fi
	
	if [ -z "$CODES" ]; then
		echo "$TEXT";
	else
		echo "\e[$(echo "$CODES" | sed 's/;$//')m$TEXT\e[0m";
	fi	
}